export interface IBook
{
    masach: string;
    tensach: string;
    theloai: string;
    link_anhbia: string;
    link_anhsau: string;
    link_trangdau:string;
    soluong: number;
    gianhap: number;
    giaban: number;
    tacgia: string;
    tinhtrang: boolean;
}