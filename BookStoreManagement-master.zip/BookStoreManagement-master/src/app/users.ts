export interface IUser
{
    manv: string,
    tennv:string,
    diachi: string,
    email: string,
    username: string,
    pass: string,
    link_avatar: string,
    _role: string,
    chucvu: string
}