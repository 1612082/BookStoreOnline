export interface IInvoice_Sold
{
   mahd:string,
   makh:string,
   manv:string,
   ngaymua: string,
   sotienban: number
}