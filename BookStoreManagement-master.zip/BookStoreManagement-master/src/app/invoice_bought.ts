export interface IInvoice_Bought
{
   mahd:string,
   macongty:string,
   manv:string,
   ngaymua: string,
   sotienmua: number
}