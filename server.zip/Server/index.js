const mysql = require('mysql');
const express = require('express');
var app = express();
const bodyparser = require('body-parser');
app.use(bodyparser.json());
var connection = mysql.createConnection({
    host: 'localhost',
    port: 3306,
    user: 'root',
    password: 'root',
    database: 'quanlynhasach',
    typeCast: function castField(field, useDefaultTypeCasting) {

        // We only want to cast bit fields that have a single-bit in them. If the field
        // has more than one bit, then we cannot assume it is supposed to be a Boolean.
        if ((field.type === "BIT") && (field.length === 1)) {

            var bytes = field.buffer();

            // A Buffer in Node represents a collection of 8-bit unsigned integers.
            // Therefore, our single "bit field" comes back as the bits '0000 0001',
            // which is equivalent to the number 1.
            return (bytes[0] === 1);

        }

        return (useDefaultTypeCasting());

    }
});
app.listen(3000, () => console.log('Express server at port: 3000'));
//START--------------------- XU LY SACH ----------------------------------------
//GET tat ca sach
app.get('/api/tatcasach', (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', 'http:localhost:4200');
    connection.query('SELECT * FROM sach', (err, rows, fields) => {
        if (!err) {
            console.log("Co dia chi lay sach: " + req.remoteAddress);
            res.send(rows);
        }
        else {
            res.send(err);
        }
    })
})
//GET sach theo ID
app.get('/api/tatcasach/:id', (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', 'http:localhost:4200')
    connection.query('SELECT * FROM sach Where masach = ? ', [req.params.id], (err, rows, fields) => {
        if (!err)
            res.send(rows);
        else
            res.send(err);
    })
})
//DELETE sach theo ID
app.delete('/api/xoasach/:id', (req, res) => {
    connection.query('DELETE from sach where masach = ? ', [req.params.id], (err, rows, fields) => {
        if (!err)
            res.send("Delete Successfull");
        else
            res.send(err);
    })
})
//Them sach moi 
app.post('/api/themsach', (req, res) => {
    var sach = req.body;
    connection.query('INSERT  INTO SACH VALUES(?,?,?,?,?,?,?,?,?,?,1)',
        [sach.masach, sach.tensach, sach.theloai, sach.link_anhbia, sach.link_anhsau, sach.link_trangdau, sach.soluong, sach.gianhap, sach.giaban, sach.tacgia],
        (err, rows, fields) => {
            if (!err)
                res.send("Add Successfull");
            else
                res.send(err);
        })
})
//Sua sach moi voi ID truyen vao
app.put('/api/tatcasach', (req, res) => {
    var sach = req.body;
    var sql = "UPDATE SACH SET tensach = ?, theloai = ?, link_anhbia = ?,link_anhsau = ?, link_trangdau =?, soluong =?,gianhap =?, giaban=?, tacgia =? \
      WHERE masach = ?"
    connection.query(sql,
        [sach.tensach, sach.theloai, sach.link_anhbia, sach.link_anhsau, sach.link_trangdau, sach.soluong, sach.gianhap, sach.giaban, sach.tacgia, sach.masach],
        (err, rows, fields) => {
            if (!err)
                res.send("Update Successfull");
            else
                res.send(err);
        })
})
//END --------------------- XU LY SACH ----------------------------------------
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//START --------------------- XU LY NHANVIEN ----------------------------------------
//GET tat ca nhanvien
app.get('/api/tatcanhanvien', (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', 'http:localhost:4200')

    connection.query('SELECT * FROM nhanvien', (err, rows, fields) => {
        if (!err) {
            res.send(rows);
        }
        else {
            res.send(err);
        }
    })
})
//GET nhanvien theo ID
app.get('/api/tatcanhanvien/:id', (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', 'http:localhost:4200')
    connection.query('SELECT * FROM nhanvien where manv = ? ', [req.params.id], (err, rows, fields) => {
        if (!err)
            res.send(rows);
        else
            res.send(err);
    })
})
//DELETE nhanvien theo ID
app.delete('/api/xoanhanvien/:id', (req, res) => {
    connection.query('DELETE from nhanvien where manv = ? ', [req.params.id], (err, rows, fields) => {
        if (!err)
            res.send("Delete successfull");
        else
            res.send(err);
    })
})
//Them nhanvien moi 
app.post('/api/themnhanvien', (req, res) => {
    var nhanvien = req.body;
    connection.query('INSERT  INTO nhanvien VALUES(?,?,?,?,?,?,?,?,?)',
        [nhanvien.manv, nhanvien.tennv, nhanvien.diachi, nhanvien.email, nhanvien.username, nhanvien.pass, nhanvien.link_avatar, nhanvien._role, nhanvien.chucvu],
        (err, rows, fields) => {
            if (!err)
                res.send("Add successfull");
            else
                res.send(err);
        })
})
//Sua nhan vieni voi ID truyen vao
app.put('/api/themnhanvien', (req, res) => {
    var nhanvien = req.body;
    var sql = "UPDATE nhanvien SET tennv = ?, diachi = ?, email = ?,username = ?, pass =?, link_avatar =?, _role=?, chucvu =? \
      WHERE manv = ?"
    connection.query(sql,
        [nhanvien.tennv, nhanvien.diachi, nhanvien.email, nhanvien.username, nhanvien.pass, nhanvien.link_avatar, nhanvien._role, nhanvien.chucvu, nhanvien.manv],
        (err, rows, fields) => {
            if (!err)
                res.send("Update successfull");
            else
                res.send(err);
        })
})
//END --------------------- XU LY NHANVIEN ----------------------------------------
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//START --------------------- XU LY HOA DON MUA ----------------------------------------
//GET tat ca HOA DON Mua
app.get('/api/tatcahoadonmua', (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', 'http:localhost:4200')
    connection.query('SELECT * FROM hoadonmua', (err, rows, fields) => {
        if (!err) {
            res.send(rows);
        }
        else {
            res.send(err);
        }
    })
})

app.get('/api/tatcahoadonban', (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', 'http:localhost:4200')
    connection.query('SELECT * FROM hoadonban', (err, rows, fields) => {
        if (!err) {
            res.send(rows);
        }
        else {
            res.send(err);
        }
    })
})

app.get('/api/danhsachmua/:id', (req, res) => {
    connection.query('SELECT * FROM danhsachsachmua where mahd = ? ', [req.params.id], (err, rows, fields) => {
        if (!err) {
            res.send(rows);

        }
        else {
            res.send(err);
            Console.log(err);
        }
    })
})
app.post('/api/themhoadonmua', (req, res) => {
    // var sql = req.body
    // connection.query(sql,
    //     (err, rows, fields) => {
    //         if (!err)
    //             res.send("Add Successfull");
    //         else
    //             res.send(err);
    //     })
    var danhsach = req.body;
    connection.query('INSERT  INTO hoadonmua VALUES(?,?,?,?)',
        [danhsach.mahd, danhsach.macongty, danhsach.ngaymuaban, danhsach.tongtien],
        (err, rows, fields) => {
            if (!err)
                res.send("Add Successfull");
            else {
                res.send(err);
                console.log(err);

            }
        })
});
app.delete('/api/xoahoadonmua/:id', (req, res) => {
    connection.query('DELETE from hoadonmua where mahd = ? ', [req.params.id], (err, rows, fields) => {
        if (!err)
            res.send("Delete successfull");
        else
            res.send(err);
    })
})
app.put('/api/suahoadonmua', (req, res) => {
    var danhsach = req.body;
    var sql = "UPDATE hoadonmua SET macongty = ?, ngaymua = ?, sotienmua = ? \
      WHERE mahd = ?"
    connection.query(sql,
        [danhsach.macongty, danhsach.ngaymuaban, danhsach.tongtien, danhsach.mahd],
        (err, rows, fields) => {
            if (!err) {
                res.send("Update Successfull");

                res.end();

            }
            else {
                console.log(err);
                res.send(err);

            }
        })
})

app.post('/api/themdanhsachmua', (req, res) => {
    // var sql = req.body
    // connection.query(sql,
    //     (err, rows, fields) => {
    //         if (!err)
    //             res.send("Add Successfull");
    //         else
    //             res.send(err);
    //     })
    var danhsach = req.body;
    danhsach.forEach(element => {
        connection.query('INSERT  INTO danhsachsachmua VALUES(?,?,?,?,?)',
            [element.mahd, element.masach, element.soluong, element.ngaymuaban, element.dongia],
            (err, rows, fields) => {
                if (!err)
                    res.send("Add Successfull");
                else {
                    res.send(err);
                    console.log(err);

                }
            })
    });

})
app.put('/api/suachitiethoadonmua', (req, res) => {
    var danhsach = req.body;
    let sql = "";
    danhsach.forEach(element => {
        // sql= sql + mysql.format('UPDATE danhsachsachmua SET soluong = ?, ngaymuaban = ?, dongia = ? \
        // WHERE mahd = ? and masach= ?')
        connection.query('UPDATE danhsachsachmua SET soluong = ?, ngaymuaban = ?, dongia = ? \
        WHERE mahd = ? and masach= ?',
            [element.soluong, element.ngaymuaban, element.dongia, element.mahd, element.masach,],
            (err, rows, fields) => {
                if (!err) {
                    res.send("Update Successfull");
                    res.end();
                }

                else {
                    res.send(err);
                    console.log(err);

                }
            })

    })


})
//=====================================================================================
//=====================================================================================
//=====================================================================================

//=====================================================================================

//=====================================================================================

//=====================================================================================

//=====================================================================================

//=====================================================================================

//=====================================================================================

//=====================================================================================

//=====================================================================================
//=====================================================================================

//=====================================================================================

//=====================================================================================


app.get('/api/danhsachban/:id', (req, res) => {
    connection.query('SELECT * FROM danhsachsachban where mahd = ? ', [req.params.id], (err, rows, fields) => {
        if (!err) {
            res.send(rows);

        }
        else {
            res.send(err);
            Console.log(err);
        }
    })
})
app.post('/api/themhoadonban', (req, res) => {
    // var sql = req.body
    // connection.query(sql,
    //     (err, rows, fields) => {
    //         if (!err)
    //             res.send("Add Successfull");
    //         else
    //             res.send(err);
    //     })
    var danhsach = req.body;
    connection.query('INSERT  INTO hoadonban VALUES(?,?,?,?)',
        [danhsach.mahd, danhsach.makh, danhsach.ngaymuaban, danhsach.tongtien],
        (err, rows, fields) => {
            if (!err)
                res.send("Add Successfull");
            else {
                res.send(err);
                console.log(err);

            }
        })
});
app.delete('/api/xoahoadonban/:id', (req, res) => {
    connection.query('DELETE from hoadonban where mahd = ? ', [req.params.id], (err, rows, fields) => {
        if (!err)
            res.send("Delete successfull");
        else
            res.send(err);
    })
})
app.put('/api/suahoadonban', (req, res) => {
    var danhsach = req.body;
    var sql = "UPDATE hoadonmua SET makh = ?, ngayban = ?, sotienban = ? \
      WHERE mahd = ?"
    connection.query(sql,
        [danhsach.makh, danhsach.ngayban, danhsach.tongtien, danhsach.mahd],
        (err, rows, fields) => {
            if (!err) {
                res.send("Update Successfull");

                res.end();

            }
            else {
                console.log(err);
                res.send(err);

            }
        })
})

app.post('/api/themdanhsachban', (req, res) => {
    // var sql = req.body
    // connection.query(sql,
    //     (err, rows, fields) => {
    //         if (!err)
    //             res.send("Add Successfull");
    //         else
    //             res.send(err);
    //     })
    var danhsach = req.body;
    danhsach.forEach(element => {
        connection.query('INSERT  INTO danhsachsachban VALUES(?,?,?,?,?)',
            [element.mahd, element.masach, element.soluong, element.ngaymuaban, element.dongia],
            (err, rows, fields) => {
                if (!err)
                    res.send("Add Successfull");
                else {
                    res.send(err);
                    console.log(err);

                }
            })
    });

})
app.put('/api/suachitiethoadonban', (req, res) => {
    var danhsach = req.body;
    danhsach.forEach(element => {

        connection.query('UPDATE danhsachsachmua SET soluong = ?, ngaymuaban = ?, dongia = ? \
        WHERE mahd = ? and masach= ?',
            [element.soluong, element.ngaymuaban, element.dongia, element.mahd, element.masach,],
            (err, rows, fields) => {
                if (!err)
                    res.send("Update Successfull");
                else {
                    res.send(err);
                    console.log(err);

                }
            })
    })
})
