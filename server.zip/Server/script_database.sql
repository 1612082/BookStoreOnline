-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: localhost    Database: quanlynhasach
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `congty`
--

DROP TABLE IF EXISTS `congty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `congty` (
  `macty` varchar(20) NOT NULL,
  `tencty` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `diachi` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `sdt` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  PRIMARY KEY (`macty`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `congty`
--

LOCK TABLES `congty` WRITE;
/*!40000 ALTER TABLE `congty` DISABLE KEYS */;
INSERT INTO `congty` VALUES ('CONGTY01','Công Ty Cổ Phần Tập Đoàn FLC',' Hà Nội, Quảng Ninh, Thanh Hoá','0938443535','flc.support@flc.com'),('CONGTY02','Công Ty Cổ Phần Tập Đoàn KFC',' Hà Nội, Quảng Ninh, Thanh Hoá','0938443535','flc.support@flc.com'),('CONGTY03','Công ty cổ phần Hạ tầng Viễn thông CMC Telecom','Hà Nội','0938443535','flc.support@flc.com'),('CONGTY04','Công ty Cổ phần CCGroup Toàn Cầu','TP.Hồ Chí Minh','0938443535','flc.support@flc.com');
/*!40000 ALTER TABLE `congty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `danhsachsachban`
--

DROP TABLE IF EXISTS `danhsachsachban`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `danhsachsachban` (
  `mahd` varchar(20) DEFAULT NULL,
  `masach` varchar(20) NOT NULL,
  `soluong` varchar(20) NOT NULL,
  `ngaymuaban` varchar(50) NOT NULL,
  `dongia` int(12) NOT NULL,
  KEY `danhsachsachban_ibfk_2` (`mahd`),
  CONSTRAINT `danhsachsachban_ibfk_2` FOREIGN KEY (`mahd`) REFERENCES `hoadonban` (`mahd`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `danhsachsachban`
--

LOCK TABLES `danhsachsachban` WRITE;
/*!40000 ALTER TABLE `danhsachsachban` DISABLE KEYS */;
INSERT INTO `danhsachsachban` VALUES ('BAN01','SACH01','30','2019-15-16',80000),('BAN01','SACH02','30','2019-15-16',80000),('BAN02','SACH01','30','2019-15-16',80000),('BAN02','SACH03','30','2019-15-16',80000),('BAN03','SACH02','30','2019-15-16',80000),('BAN03','SACH03','30','2019-15-16',80000),('BAN03','SACH04','30','2019-15-16',80000),('BAN10','SACH05','10','6/18/2019',50000),('BAN11','SACH05','15','2019-06-22',100000);
/*!40000 ALTER TABLE `danhsachsachban` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `danhsachsachmua`
--

DROP TABLE IF EXISTS `danhsachsachmua`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `danhsachsachmua` (
  `mahd` varchar(20) DEFAULT NULL,
  `masach` varchar(20) NOT NULL,
  `soluong` varchar(20) NOT NULL,
  `ngaymuaban` varchar(50) NOT NULL,
  `dongia` int(12) DEFAULT NULL,
  KEY `danhsachsachmua_ibfk_1` (`masach`),
  KEY `danhsachsachmua_ibfk_2` (`mahd`),
  CONSTRAINT `danhsachsachmua_ibfk_1` FOREIGN KEY (`masach`) REFERENCES `sach` (`masach`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `danhsachsachmua_ibfk_2` FOREIGN KEY (`mahd`) REFERENCES `hoadonmua` (`mahd`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `danhsachsachmua`
--

LOCK TABLES `danhsachsachmua` WRITE;
/*!40000 ALTER TABLE `danhsachsachmua` DISABLE KEYS */;
INSERT INTO `danhsachsachmua` VALUES ('MUA01','SACH01','10','2019-04-15',80000),('MUA01','SACH03','15','2019-04-15',90000),('MUA02','SACH04','10','2019-04-15',70000),('MUA02','SACH05','10','2019-04-15',80000),('MUA02','SACH06','10','2019-04-15',80000),('MUA03','SACH04','10','2019-04-15',80000),('MUA03','SACH06','10','2019-04-15',80000),('MUA03','SACH04','10','2019-04-15',80000),('MUA03','SACH04','10','2019-04-15',80000),('MUA04','SACH03','5','2019-05-15',800000),('MUA04','SACH04','5','2019-05-15',900000),('MUA05','SACH01','10','2019-08-19',60000);
/*!40000 ALTER TABLE `danhsachsachmua` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hoadonban`
--

DROP TABLE IF EXISTS `hoadonban`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `hoadonban` (
  `mahd` varchar(20) NOT NULL,
  `makh` varchar(20) DEFAULT NULL,
  `ngayban` varchar(50) NOT NULL,
  `sotienban` bigint(12) DEFAULT NULL,
  PRIMARY KEY (`mahd`),
  KEY `hoadonban_ibfk_1` (`makh`),
  CONSTRAINT `hoadonban_ibfk_1` FOREIGN KEY (`makh`) REFERENCES `khachhang` (`makh`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hoadonban`
--

LOCK TABLES `hoadonban` WRITE;
/*!40000 ALTER TABLE `hoadonban` DISABLE KEYS */;
INSERT INTO `hoadonban` VALUES ('BAN01','KHACHHANG01','2019-04-10',150000),('BAN02','KHACHHANG02','2019-04-09',250000),('BAN03','KHACHHANG03','2019-04-08',350000),('BAN04','KHACHHANG04','2019-04-07',450000),('BAN06','KHACHHANG02','6/11/2019',600000),('BAN07','KHACHHANG01','2019-12-16',450000),('BAN08','KHACHHANG02','2019-12-16',500000),('BAN10','KHACHHANG02','6/18/2019',500000),('BAN11','KHACHHANG02','2019-06-22',1500000);
/*!40000 ALTER TABLE `hoadonban` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hoadonmua`
--

DROP TABLE IF EXISTS `hoadonmua`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `hoadonmua` (
  `mahd` varchar(20) NOT NULL,
  `macongty` varchar(20) DEFAULT NULL,
  `ngaymua` varchar(90) NOT NULL,
  `sotienmua` int(12) DEFAULT NULL,
  PRIMARY KEY (`mahd`),
  KEY `hoadonmua_ibfk_1` (`macongty`),
  CONSTRAINT `hoadonmua_ibfk_1` FOREIGN KEY (`macongty`) REFERENCES `congty` (`macty`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hoadonmua`
--

LOCK TABLES `hoadonmua` WRITE;
/*!40000 ALTER TABLE `hoadonmua` DISABLE KEYS */;
INSERT INTO `hoadonmua` VALUES ('MUA01','CONGTY01','2019-04-15',2310000),('MUA02','CONGTY02','2019-04-08',2300000),('MUA03','CONGTY03','2019-04-08',2400000),('MUA04','CONGTY01','2019-05-15',8500000),('MUA05','CONGTY02','2019-08-19',600000);
/*!40000 ALTER TABLE `hoadonmua` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `khachhang`
--

DROP TABLE IF EXISTS `khachhang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `khachhang` (
  `makh` varchar(20) NOT NULL,
  `tenkh` varchar(60) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `sono` int(12) NOT NULL,
  `sdt` varchar(16) NOT NULL,
  `email` varchar(20) NOT NULL,
  PRIMARY KEY (`makh`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `khachhang`
--

LOCK TABLES `khachhang` WRITE;
/*!40000 ALTER TABLE `khachhang` DISABLE KEYS */;
INSERT INTO `khachhang` VALUES ('KHACHHANG01','CHỊ: HẠNH',0,'0908010644','hanh@gmail.com'),('KHACHHANG02','ANH: THANH',120000,'0908121842','hanh@gmail.com'),('KHACHHANG03','CHỊ: KIM OANH',20000,'0908121842','hanh@gmail.com'),('KHACHHANG04','CHỊ: NHUNG',0,'0908121842','hanh@gmail.com'),('KHACHHANG05','ANH: TƯỜNG',0,'0908121842','hanh@gmail.com');
/*!40000 ALTER TABLE `khachhang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nhanvien`
--

DROP TABLE IF EXISTS `nhanvien`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `nhanvien` (
  `manv` varchar(20) NOT NULL,
  `tennv` varchar(60) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `diachi` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `email` varchar(60) DEFAULT NULL,
  `username` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `link_avatar` text,
  `_role` varchar(20) NOT NULL,
  `chucvu` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`manv`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nhanvien`
--

LOCK TABLES `nhanvien` WRITE;
/*!40000 ALTER TABLE `nhanvien` DISABLE KEYS */;
INSERT INTO `nhanvien` VALUES ('NV01','Phạm Phú Quốc Bảo123','79 Ca Van Thinh','baoit128@gmail.com','admin','admin1','https://scontent.fsgn5-7.fna.fbcdn.net/v/t1.0-9/20992957_509786432704462_6107894385925675733_n.jpg?_nc_cat=103&_nc_oc=AQkbwNBIT3m-QwuKTshIT0jr5byDyEku2iP3_a03pnhqyJr5acV90I950e3Ujq6Ov4A&_nc_ht=scontent.fsgn5-7.fna&oh=2f24f3c05505e5673376a39ab2ac366a&oe=5D54104A','Admin','Quản Lý'),('NV02','Nguyễn Hồng Đăng123','15 Đướng số 6 ','hongdangnguyen@gmail.com','admin1','admin2','https://scontent.fsgn5-2.fna.fbcdn.net/v/t1.0-9/21272404_1982369251998001_3568278493879074097_n.jpg?_nc_cat=107&_nc_oc=AQnP4U572hCxXcUA2627oM8WgNeHefr1K9N-0i-XI0BbH52VY2rUlHnqAfbN5dyog2Y&_nc_ht=scontent.fsgn5-2.fna&oh=310be7b64f740606f17525a139225592&oe=5D8BC2B3','Admin','Quản Lý'),('NV03','Trần Quốc Anh','15 Đướng số 6 ','hongdangnguyen@gmail.com','quocanh','quocanh','https://scontent.fsgn5-2.fna.fbcdn.net/v/t1.0-9/24294220_1291845130960666_7878160487225770742_n.jpg?_nc_cat=107&_nc_oc=AQmERSOEzDTWCtNrhczvkVFAAc3lwDbh3wQUYrn3RcQGQHUij1j4yxt3gz2t5_zJD4M&_nc_ht=scontent.fsgn5-2.fna&oh=4c41fccb53038b094668995116c0f61b&oe=5D9A2B1A','Staff','Nhân Viên'),('NV04','Phan Hải Bình','15 Đướng số 6 ','hongdangnguyen@gmail.com','haibinh','haibinh','https://scontent.fsgn5-7.fna.fbcdn.net/v/t1.0-1/61948891_2343558232523105_6919739256466309120_n.jpg?_nc_cat=103&_nc_oc=AQl3yKR1nunHpKHAndoSeVq1zhU_w7juJdYU8Vp68Jv3BtSlEhwY2XYBM93cGsb3zJA&_nc_ht=scontent.fsgn5-7.fna&oh=96f5b30bc3bf56e91a73e9fb5d5935d6&oe=5D947C7E','Staff','Nhân Viên'),('NV05','Lâm Tề Hào','15 Đướng số 6 ','hongdangnguyen@gmail.com','tehao','tehao','https://scontent.fsgn5-6.fna.fbcdn.net/v/t1.0-9/14237732_1302297919795367_1306938097152741713_n.jpg?_nc_cat=106&_nc_oc=AQmefwlgc85hR-rF2gFzgRTEz8i06kX4OlBHHndLAQix4Wsqz_IpTVvpzc1OXnQy1ZI&_nc_ht=scontent.fsgn5-6.fna&oh=554c8fe79d05df6dc021b64207b685f9&oe=5D7CC4B8','Staff','Nhân Viên'),('NV06','Phạm Phú Quốc Bảo','79 Ca Van Thinh','baoit128@gmail.com','admin','admin1','https://scontent.fsgn5-7.fna.fbcdn.net/v/t1.0-9/20992957_509786432704462_6107894385925675733_n.jpg?_nc_cat=103&_nc_oc=AQkbwNBIT3m-QwuKTshIT0jr5byDyEku2iP3_a03pnhqyJr5acV90I950e3Ujq6Ov4A&_nc_ht=scontent.fsgn5-7.fna&oh=2f24f3c05505e5673376a39ab2ac366a&oe=5D54104A','Admin','Quản Lý'),('NV10','Tom Cao','fasfas','baoit128@gmail.com','tomcao','tomcao','https://scontent.fsgn5-3.fna.fbcdn.net/v/t1.0-9/50492073_482141985645338_319783894557655040_n.jpg?_nc_cat=111&_nc_oc=AQkIwZVuvHcAkml8MW67InOst2Fyuv5t2J2g_m5uiTpPLgstVH50DvT4tE5RQLH79DY&_nc_ht=scontent.fsgn5-3.fna&oh=736abff2ddb6a31e868f5320f4f2992c&oe=5D98C50E','User','Nhan Vien');
/*!40000 ALTER TABLE `nhanvien` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sach`
--

DROP TABLE IF EXISTS `sach`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `sach` (
  `masach` varchar(20) NOT NULL,
  `tensach` varchar(60) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `theloai` varchar(60) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `link_anhbia` varchar(120) NOT NULL,
  `link_anhsau` varchar(120) DEFAULT NULL,
  `link_trangdau` varchar(120) DEFAULT NULL,
  `soluong` int(6) NOT NULL,
  `gianhap` int(12) NOT NULL,
  `giaban` int(12) NOT NULL,
  `tacgia` varchar(60) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `tinhtrang` bit(1) DEFAULT NULL,
  PRIMARY KEY (`masach`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sach`
--

LOCK TABLES `sach` WRITE;
/*!40000 ALTER TABLE `sach` DISABLE KEYS */;
INSERT INTO `sach` VALUES ('SACH01','Code Dạo Kí Sự - Lập Trình Viên Đâu Phải Chỉ Biết Code123','Sách Khoa Học & Kỹ Thuật','https://salt.tikicdn.com/ts/bookpreview/04/86/580509/files/OEBPS/Images/IMG_20170803_0001.gif','https://salt.tikicdn.com/ts/bookpreview/04/86/580509/files/OEBPS/Images/IMG_20170803_0002.gif','https://salt.tikicdn.com/ts/bookpreview/04/86/580509/files/OEBPS/Images/IMG_20170803_0003.gif',50,80000,100000,'Phạm Huy Hoàng (Developer)',_binary ''),('SACH02','FASFAS','Sách Khoa Học & Kỹ Thuật','FASFAS','FSAFAS','FASFA',45,456456,45645646,'ASFASFAS123',_binary ''),('SACH03','Kẻ Trộm Sách (Tái Bản)','Sách Văn Học','https://salt.tikicdn.com/ts/bookpreview/3c/87/734162/files/OEBPS/Images/img175.gif','https://salt.tikicdn.com/ts/bookpreview/3c/87/734162/files/OEBPS/Images/img176.gif','https://salt.tikicdn.com/ts/bookpreview/3c/87/734162/files/OEBPS/Images/img177.gif',45,90000,110000,'Markus Zusak',_binary ''),('SACH04','Bạn Đắt Giá Bao Nhiêu?','Sách Kỹ Năng Sống','https://salt.tikicdn.com/cache/w1200/ts/product/87/c9/c0/bfebf4adcb31c8eb5c39fd3779cc4b68.jpg','','',50,70000,85000,'Vãn Tình',_binary ''),('SACH05','Đắc Nhân Tâm (Khổ Lớn)','Sách Kỹ Năng Sống','https://salt.tikicdn.com/ts/bookpreview/9c/c7/480040/files/OEBPS/Images/img592.gif','https://salt.tikicdn.com/ts/bookpreview/9c/c7/480040/files/OEBPS/Images/img593.gif','https://salt.tikicdn.com/ts/bookpreview/9c/c7/480040/files/OEBPS/Images/img594.gif',30,80000,95000,'Dale Carnegie',_binary ''),('SACH06','Hành Trình Về Phương Đông (Tái Bản)','Sách Kỹ Năng Sống','https://salt.tikicdn.com/ts/bookpreview/ff/cf/463044/files/OEBPS/Images/img203.gif','https://salt.tikicdn.com/ts/bookpreview/ff/cf/463044/files/OEBPS/Images/img204.gif','https://salt.tikicdn.com/ts/bookpreview/ff/cf/463044/files/OEBPS/Images/img205.gif',50,80000,105000,'Baird T. Spalding',_binary ''),('SACH07','Nhà Giả Kim','Sách Văn Học','https://salt.tikicdn.com/ts/bookpreview/e9/ff/378448/files/OEBPS/Images/IMG_20170802_0024.gif','https://salt.tikicdn.com/ts/bookpreview/e9/ff/378448/files/OEBPS/Images/IMG_20170802_0025.gif','https://salt.tikicdn.com/ts/bookpreview/e9/ff/378448/files/OEBPS/Images/IMG_20170802_0026.gif',20,60000,750000,'Paulo Coelho',_binary ''),('SACH08','Thám Tử Lừng Danh Conan - Tập 95','Truyện Tranh Manga, Comic','https://salt.tikicdn.com/cache/w1200/ts/product/59/31/e5/5a6c39c0b9229088a765de43cfd79838.jpg','','',35,15000,180000,'Gosho Aoyama,  Eiichi Yamagishi',_binary ''),('SACH09','Tony Buổi Sáng - Trên Đường Băng (Tái Bản 2017)','Sách Kỹ Năng Sống','https://salt.tikicdn.com/ts/bookpreview/42/2a/1005148/files/OEBPS/Images/img677.gif','https://salt.tikicdn.com/ts/bookpreview/42/2a/1005148/files/OEBPS/Images/img678.gif','https://salt.tikicdn.com/ts/bookpreview/42/2a/1005148/files/OEBPS/Images/img679.gif',25,75000,95000,'Tony Buổi Sáng',_binary ''),('SACH10','Code Dạo Kí Sự - Lập Trình Viên Đâu Phải Chỉ Biết Code','Sách Khoa Học & Kỹ Thuật','https://salt.tikicdn.com/ts/bookpreview/04/86/580509/files/OEBPS/Images/IMG_20170803_0001.gif','https://salt.tikicdn.com/ts/bookpreview/04/86/580509/files/OEBPS/Images/IMG_20170803_0002.gif','https://salt.tikicdn.com/ts/bookpreview/04/86/580509/files/OEBPS/Images/IMG_20170803_0003.gif',50,80000,100000,'Phạm Huy Hoàng (Developer)',_binary ''),('SACH12','De men phieu luu ky','Sách Văn Học','https://salt.tikicdn.com/ts/bookpreview/04/86/580509/files/OEBPS/Images/IMG_20170803_0003.gif','link','link',50,80000,90000,'To Hoai',_binary '');
/*!40000 ALTER TABLE `sach` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'quanlynhasach'
--
/*!50003 DROP PROCEDURE IF EXISTS `ThemHoacSuaSach` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `ThemHoacSuaSach`(
IN _masach varchar(20),
IN _tensach NVARCHAR(60),
IN _theloai NVARCHAR(60),
IN _link_anhbia varchar(120),
IN _link_anhsau varchar(120),
in _link_trangdau varchar(120),
IN _soluong int(6) ,
IN _gianhap int(12) ,
IN _giaban int(12),
IN _tacgia NVARCHAR(60)
)
BEGIN
    DECLARE _maxsach INT;
    select _maxsach = count(*) from sach;
	IF _masach = 0
    then
        set _masach = "SACH" + _maxsach;
	select _masach;
    insert into sach  (`masach`,`tensach`,`theloai`,`link_anhbia`,`link_anhsau`,`link_trangdau`,`soluong`,`gianhap`,`giaban`,`tacgia`,`tinhtrang`)  
    VALUES (_masach,_tensach,_theloai,_link_anhbia,_link_anhsau,_link_trangdau,_soluong,_gianhap,_giaban,_tacgia,1);

    
    else
    UPDATE sach
    set tenhsach = _tensach,theloai = _theloai,link_anhbia = _link_anhbia,linkanhsau = _link_anhsau,link_trangdau = _link_trangdau,soluong= _soluong,gianhap= _gianhap,giaban=_giaban,tacgia=_tacgia,tinhtrang=_tinhtrang
    where masach = _masach;
    end if;
    select _masach as 'masach';
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `THEMHOADONMUA` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `THEMHOADONMUA`(
in _soluongsach int,
in _mahoadon varchar(20),
in _macongty varchar(20),
in _manv varchar(20),
in _ngaymua date,
in _danhsachsach json
)
BEGIN
set @i = 0;
WHILE(@i < _soluongsach) do
	SELECT JSON_EXTRACT(_danhsachsach, '$[@i]') as pro;
	set @i = @i +1;
END WHILE;

	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-06-24 23:08:43
